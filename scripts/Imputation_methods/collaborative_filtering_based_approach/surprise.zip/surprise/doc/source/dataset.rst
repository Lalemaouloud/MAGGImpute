.. _dataset:

dataset module
===================

.. automodule:: surprise.dataset
    :members:
    :exclude-members: BuiltinDataset, read_ratings, DatasetUserFolds,
