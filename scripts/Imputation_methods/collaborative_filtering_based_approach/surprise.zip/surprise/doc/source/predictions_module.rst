.. _pred_package_predictions:

The predictions module
------------------------

.. automodule:: surprise.prediction_algorithms.predictions
    :members:
    :exclude-members: all_ratings, all_xs, all_ys

