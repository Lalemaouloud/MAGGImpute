.. _reader:

Reader class
============

.. autoclass:: surprise.reader.Reader
    :members:
    :exclude-members: parse_line

